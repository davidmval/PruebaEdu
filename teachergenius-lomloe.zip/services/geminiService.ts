import { GoogleGenAI } from "@google/genai";
import { ActionType } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const getPromptForAction = (course: string, topic: string, action: ActionType): string => {
  const baseContext = `Eres un experto consultor educativo especializado en el sistema educativo español (LOMLOE). Estás ayudando a un profesor del curso "${course}" a preparar el tema "${topic}".`;

  switch (action) {
    case ActionType.BRAINSTORMING:
      return `${baseContext} Genera una lluvia de ideas creativa (Brainstorming) con al menos 10 conceptos clave, enfoques o preguntas disparadoras para introducir o tratar este tema en clase. Sé original.`;
    
    case ActionType.ACTIVITIES_FUN:
      return `${baseContext} Propón 3 actividades lúdicas o de gamificación para trabajar este tema. Incluye: Nombre de la actividad, mecánica, materiales necesarios y objetivo de aprendizaje.`;
    
    case ActionType.MOVIE:
      return `${baseContext} Recomienda 2 o 3 películas o documentales adecuados para la edad del alumnado de este curso que sirvan para ilustrar el tema. Explica por qué son relevantes y sugiere 2 preguntas para el debate posterior.`;
    
    case ActionType.FIELD_TRIP:
      return `${baseContext} Teniendo en cuenta que el centro educativo se encuentra en **Monreal del Campo (Teruel)** y buscando el **mínimo coste posible (o coste cero)**: Sugiere una excursión, salida de campo o visita en el entorno cercano (comarca del Jiloca, Teruel provincia) que permita profundizar en el tema. Si no hay un lugar específico relacionado con el tema cerca, propón una actividad de observación en el entorno natural o urbano inmediato del pueblo. Describe la actividad y qué deberían observar los alumnos.`;
    
    case ActionType.BOOK:
      return `${baseContext} Recomienda un libro (ficción o ensayo adaptado al nivel) que esté relacionado con el tema. Incluye título, autor y una breve sinopsis de por qué es útil para la clase.`;
    
    case ActionType.YOUTUBE:
      return `${baseContext} Recomienda un vídeo de YouTube o un canal específico educativo que trate este tema con rigor y sea ameno. Describe el contenido del vídeo y qué conceptos clarifica. (Nota: Proporciona términos de búsqueda exactos).`;
    
    case ActionType.EXTENSION:
      return `${baseContext} Diseña 3 ejercicios de ampliación para alumnos que terminan rápido o necesitan mayor reto. Deben requerir investigación, pensamiento crítico o creatividad superior.`;
    
    case ActionType.SITUACION_APRENDIZAJE:
      return `${baseContext} Diseña una Situación de Aprendizaje completa según la normativa LOMLOE. Debe incluir: 
      1. Título motivador.
      2. Justificación y vinculación con la vida real.
      3. Competencias Específicas trabajadas.
      4. Saberes Básicos.
      5. Descripción de la secuencia didáctica (breve).
      6. Producto final evaluable.`;
    
    default:
      return `${baseContext} Genera contenido educativo relevante.`;
  }
};

export const generateEducationalContent = async (
  course: string, 
  topic: string, 
  action: ActionType
): Promise<string> => {
  try {
    const prompt = getPromptForAction(course, topic, action);
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        temperature: 0.7, // Balance between creativity and structure
        topP: 0.8,
        topK: 40,
      }
    });

    return response.text || "No se pudo generar el contenido. Por favor, inténtalo de nuevo.";
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "Ocurrió un error al conectar con el asistente inteligente. Verifica tu conexión o intenta más tarde.";
  }
};