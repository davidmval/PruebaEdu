export enum ActionType {
  BRAINSTORMING = 'BRAINSTORMING',
  ACTIVITIES_FUN = 'ACTIVITIES_FUN',
  MOVIE = 'MOVIE',
  FIELD_TRIP = 'FIELD_TRIP',
  BOOK = 'BOOK',
  YOUTUBE = 'YOUTUBE',
  EXTENSION = 'EXTENSION',
  SITUACION_APRENDIZAJE = 'SITUACION_APRENDIZAJE'
}

export interface GeneratorState {
  course: string;
  topic: string;
  isConfigured: boolean;
}

export interface GeneratedContent {
  type: ActionType;
  content: string;
  timestamp: number;
}