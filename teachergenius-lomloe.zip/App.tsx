import React, { useState, useRef, useEffect } from 'react';
import { ActionType, GeneratorState, GeneratedContent } from './types';
import { generateEducationalContent } from './services/geminiService';
import { 
  BrainIcon, GameIcon, FilmIcon, MapIcon, BookIcon, 
  VideoIcon, RocketIcon, GraduationCapIcon, ArrowLeftIcon, SparklesIcon
} from './components/Icons';

function App() {
  const [state, setState] = useState<GeneratorState>({
    course: '',
    topic: '',
    isConfigured: false,
  });

  const [isLoading, setIsLoading] = useState(false);
  const [activeAction, setActiveAction] = useState<ActionType | null>(null);
  const [result, setResult] = useState<GeneratedContent | null>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (state.course.trim() && state.topic.trim()) {
      setState(prev => ({ ...prev, isConfigured: true }));
    }
  };

  const handleReset = () => {
    setState({ course: '', topic: '', isConfigured: false });
    setResult(null);
    setActiveAction(null);
  };

  const handleAction = async (action: ActionType) => {
    setIsLoading(true);
    setActiveAction(action);
    setResult(null); // Clear previous result while loading

    const content = await generateEducationalContent(state.course, state.topic, action);
    
    setResult({
      type: action,
      content,
      timestamp: Date.now()
    });
    setIsLoading(false);
  };

  // Scroll to result when it appears
  useEffect(() => {
    if (result && resultRef.current) {
      resultRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [result]);

  const actions = [
    { type: ActionType.BRAINSTORMING, label: 'Lluvia de Ideas', icon: BrainIcon, color: 'bg-blue-500', hover: 'hover:bg-blue-600' },
    { type: ActionType.ACTIVITIES_FUN, label: 'Actividades Lúdicas', icon: GameIcon, color: 'bg-green-500', hover: 'hover:bg-green-600' },
    { type: ActionType.MOVIE, label: 'Recomendar Película', icon: FilmIcon, color: 'bg-red-500', hover: 'hover:bg-red-600' },
    { type: ActionType.FIELD_TRIP, label: 'Excursión Educativa', icon: MapIcon, color: 'bg-amber-500', hover: 'hover:bg-amber-600' },
    { type: ActionType.BOOK, label: 'Recomendar Libro', icon: BookIcon, color: 'bg-indigo-500', hover: 'hover:bg-indigo-600' },
    { type: ActionType.YOUTUBE, label: 'Vídeo YouTube', icon: VideoIcon, color: 'bg-rose-500', hover: 'hover:bg-rose-600' },
    { type: ActionType.EXTENSION, label: 'Ejercicios Ampliación', icon: RocketIcon, color: 'bg-purple-500', hover: 'hover:bg-purple-600' },
    { type: ActionType.SITUACION_APRENDIZAJE, label: 'Situación de Aprendizaje (LOMLOE)', icon: GraduationCapIcon, color: 'bg-slate-800', hover: 'hover:bg-slate-900', fullWidth: true },
  ];

  // Helper to render markdown-like text
  const renderContent = (text: string) => {
    const sections = text.split('\n');
    return sections.map((line, idx) => {
      // Headers
      if (line.startsWith('### ')) return <h3 key={idx} className="text-xl font-bold text-slate-800 mt-6 mb-2">{line.replace('### ', '')}</h3>;
      if (line.startsWith('## ')) return <h2 key={idx} className="text-2xl font-bold text-slate-900 mt-8 mb-4 border-b pb-2">{line.replace('## ', '')}</h2>;
      if (line.startsWith('# ')) return <h1 key={idx} className="text-3xl font-bold text-slate-900 mt-4 mb-6">{line.replace('# ', '')}</h1>;
      
      // List items
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        return <li key={idx} className="ml-4 pl-2 list-disc text-slate-700 mb-1">{line.replace(/^[-*] /, '')}</li>;
      }
      if (/^\d+\./.test(line.trim())) {
         return <li key={idx} className="ml-4 pl-2 list-decimal text-slate-700 mb-1">{line.replace(/^\d+\. /, '')}</li>;
      }

      // Bold text (simplified regex)
      const parts = line.split(/(\*\*.*?\*\*)/g);
      
      return (
        <p key={idx} className="mb-3 text-slate-700 leading-relaxed">
          {parts.map((part, i) => {
            if (part.startsWith('**') && part.endsWith('**')) {
              return <strong key={i} className="font-semibold text-slate-900">{part.slice(2, -2)}</strong>;
            }
            return part;
          })}
        </p>
      );
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-blue-100">
      
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="bg-blue-600 p-1.5 rounded-lg">
               <SparklesIcon className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600">
              TeacherGenius <span className="text-slate-500 font-medium text-sm ml-1">LOMLOE Edition</span>
            </h1>
          </div>
          {state.isConfigured && (
            <button 
              onClick={handleReset}
              className="text-sm font-medium text-slate-500 hover:text-blue-600 flex items-center space-x-1 transition-colors"
            >
              <ArrowLeftIcon className="w-4 h-4" />
              <span>Cambiar Tema</span>
            </button>
          )}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Step 1: Input Configuration */}
        {!state.isConfigured ? (
          <div className="max-w-2xl mx-auto mt-12 animate-fade-in">
            <div className="bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden">
              <div className="bg-blue-600 px-8 py-6">
                <h2 className="text-2xl font-bold text-white mb-2">Comencemos a planificar</h2>
                <p className="text-blue-100">Introduce los detalles del curso y tema para generar recursos personalizados.</p>
              </div>
              <form onSubmit={handleSubmit} className="p-8 space-y-6">
                <div>
                  <label htmlFor="course" className="block text-sm font-medium text-slate-700 mb-1">Nivel Educativo / Curso</label>
                  <input
                    type="text"
                    id="course"
                    required
                    placeholder="Ej: 3º ESO, 2º Primaria, Bachillerato..."
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all placeholder-slate-400 bg-slate-50 focus:bg-white"
                    value={state.course}
                    onChange={(e) => setState({ ...state, course: e.target.value })}
                  />
                </div>
                <div>
                  <label htmlFor="topic" className="block text-sm font-medium text-slate-700 mb-1">Tema a tratar</label>
                  <input
                    type="text"
                    id="topic"
                    required
                    placeholder="Ej: La Guerra Civil Española, Las Plantas, Fotosíntesis..."
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all placeholder-slate-400 bg-slate-50 focus:bg-white"
                    value={state.topic}
                    onChange={(e) => setState({ ...state, topic: e.target.value })}
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold py-4 rounded-xl transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 active:translate-y-0 flex justify-center items-center space-x-2"
                >
                  <SparklesIcon className="w-5 h-5" />
                  <span>Generar Recursos</span>
                </button>
              </form>
            </div>
          </div>
        ) : (
          <div className="space-y-8 animate-fade-in">
            {/* Info Banner */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Trabajando en</p>
                <h2 className="text-2xl font-bold text-slate-900">{state.topic}</h2>
                <p className="text-slate-600">{state.course}</p>
              </div>
              <div className="hidden sm:block">
                 <div className="h-12 w-12 rounded-full bg-blue-50 flex items-center justify-center text-2xl">
                    📚
                 </div>
              </div>
            </div>

            {/* Step 2: Action Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {actions.map((action) => {
                const Icon = action.icon;
                const isActive = activeAction === action.type;
                
                return (
                  <button
                    key={action.type}
                    onClick={() => handleAction(action.type)}
                    disabled={isLoading}
                    className={`
                      ${action.fullWidth ? 'sm:col-span-2 lg:col-span-4' : ''}
                      relative overflow-hidden group p-6 rounded-xl text-left transition-all duration-300
                      ${isActive 
                        ? 'ring-2 ring-offset-2 ring-blue-500 bg-white shadow-md transform scale-[1.02]' 
                        : 'bg-white hover:bg-slate-50 shadow-sm border border-slate-200 hover:shadow-md hover:-translate-y-1'
                      }
                      ${isLoading && !isActive ? 'opacity-50 cursor-not-allowed' : ''}
                    `}
                  >
                    <div className={`
                      inline-flex items-center justify-center p-3 rounded-lg mb-4 text-white shadow-sm transition-transform group-hover:scale-110
                      ${action.color}
                    `}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-700 transition-colors">
                      {action.label}
                    </h3>
                    <p className="text-sm text-slate-500 mt-2 line-clamp-2">
                       Generar contenido con IA adaptado al tema.
                    </p>
                    {isActive && isLoading && (
                      <div className="absolute inset-0 bg-white/50 flex items-center justify-center backdrop-blur-sm">
                        <div className="w-6 h-6 border-3 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Step 3: Results Display */}
            {result && (
              <div ref={resultRef} className="animate-slide-up scroll-mt-24 pb-12">
                 <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
                    <div className={`px-8 py-6 border-b border-slate-100 flex items-center justify-between ${
                      actions.find(a => a.type === result.type)?.color.replace('bg-', 'bg-opacity-10 bg-') || 'bg-slate-50'
                    }`}>
                       <div className="flex items-center space-x-3">
                          <div className={`p-2 rounded-lg text-white ${actions.find(a => a.type === result.type)?.color}`}>
                            {React.createElement(actions.find(a => a.type === result.type)?.icon || SparklesIcon, { className: "w-5 h-5" })}
                          </div>
                          <h3 className="text-xl font-bold text-slate-800">
                            {actions.find(a => a.type === result.type)?.label}
                          </h3>
                       </div>
                       <span className="text-sm text-slate-400 font-mono">
                         Generado con IA
                       </span>
                    </div>
                    
                    <div className="p-8 bg-white min-h-[300px] prose-content overflow-y-auto max-h-[800px]">
                       {renderContent(result.content)}
                    </div>
                 </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

export default App;